<?php
echo "Copyright &copy; by Thin Ba Shane (@art0flunam00n) ";
?>
