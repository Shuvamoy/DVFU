<br><div class="collection">
        <a href="../index.php" class="collection-item">Home</a>
        <a href="fu1.php" class="collection-item">Level 1</a>
        <a href="fu2.php" class="collection-item">Level 2</a>
        <a href="fu3.php" class="collection-item">Level 3</a>
        <a href="fu4.php" class="collection-item">Level 4</a>
        <a href="fu5.php" class="collection-item">Level 5</a>
        <a href="fu6.php" class="collection-item">Level 6</a>
        <a href="fu7.php" class="collection-item">Level 7</a>
</div>
