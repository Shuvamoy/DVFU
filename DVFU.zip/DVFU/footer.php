<?php
echo "Developed by LOL Security  ( <a href='http://locatiom-href.com'> - Link </a> )";
?>
