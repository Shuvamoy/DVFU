<br><div class="collection">
        <a href="index.php" class="collection-item">Home</a>
        <a href="vulnerabilities/fu1.php" class="collection-item">Level 1</a>
        <a href="vulnerabilities/fu2.php" class="collection-item">Level 2</a>
        <a href="vulnerabilities/fu3.php" class="collection-item">Level 3</a>
        <a href="vulnerabilities/fu4.php" class="collection-item">Level 4</a>
        <a href="vulnerabilities/fu5.php" class="collection-item">Level 5</a>
        <a href="vulnerabilities/fu6.php" class="collection-item">Level 6</a>
        <a href="vulnerabilities/fu7.php" class="collection-item">Level 7</a>
</div>
